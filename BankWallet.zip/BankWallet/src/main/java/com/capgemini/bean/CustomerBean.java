package com.capgemini.bean;

public class CustomerBean {
	private int accno;
	private String name;
	private String phneNo;
	private int age;
	private double amt;
	static private int accNumGen = 10850;
	private String custPwd;
	public int getAccNum() {
		return accno;
	}
	public void setAccNum() {
		this.accno = accNumGen++;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhneNo() {
		return phneNo;
	}
	public void setPhneNo(String phneNo) {
		this.phneNo = phneNo;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getAmt() {
		return amt;
	}
	public void setAmt(double amt) {
		this.amt = amt;
	}
	public String getCustPwd() {
		return custPwd;
	}
	public void setCustPwd(String custPwd) {
		this.custPwd = custPwd;
	}
}
