package com.capgemini.test;

import junit.framework.Assert;

import org.junit.Test;



import com.capgemini.bean.CustomerBean;
import com.capgemini.dao.CustomerDao;
import com.capgemini.service.CustomerService;

public class CustomerTest {
	@Test
	public void testValidatePhoneNo() {
		CustomerService check = new CustomerService();
	
	Assert.assertEquals(true, check.validateCustPhoneNumber("9874563210"));
		
	}
	
	@Test
	public void testValidateName() {
		CustomerService check = new CustomerService();
	
	Assert.assertEquals(true, check.validateCustName("Peter Parker"));
		
	}
	
	@Test
	public void testValidatePwd() {
		CustomerService check = new CustomerService();
	
	Assert.assertEquals(true, check.validateCustPwd("Abcd123@"));
		
	}

	@Test
	public void testValidateAge()
	{
		CustomerService check = new CustomerService();
		Assert.assertEquals(true, check.validateCustAge(34));
	}
	
	@Test
	public void testValidateAmt()
	{
		CustomerService check = new CustomerService();
		Assert.assertEquals(true, check.validateAmt(2000.00));
	}
	@Test
	public void testValidatePhoneNoFail() {
		CustomerService check = new CustomerService();
	
	Assert.assertEquals(false, check.validateCustPhoneNumber("8745621212121"));
		
	}
	
	@Test
	public void testValidateNameFail() {
		CustomerService check = new CustomerService();
	
	Assert.assertEquals(false, check.validateCustName("Matt123"));
		
	}
	
	@Test
	public void testValidatePwdFail() {
		CustomerService check = new CustomerService();
	
	Assert.assertEquals(false, check.validateCustPwd("@! SAm.IY"));
		
	}

	@Test
	public void testValidateAgeFail()
	{
		CustomerService check = new CustomerService();
		Assert.assertEquals(false, check.validateCustAge(152));
	}
	
	@Test
	public void testValidateAmtFail()
	{
		CustomerService check = new CustomerService();
		Assert.assertEquals(false, check.validateAmt(0.00));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testAccCreation()
	{
		com.capgemini.dao.CustomerDao w = new CustomerDao();
		CustomerBean a = new CustomerBean();
		Assert.assertEquals(10100,w.accCreation(a));
		CustomerBean a1 = new CustomerBean();
		Assert.assertEquals(10101,w.accCreation(a1));
		CustomerBean a2 = new CustomerBean();
		Assert.assertEquals(10102,w.accCreation(a2));
		
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testDepositAmt()
	{
		CustomerService w = new CustomerService();
		CustomerBean a = new CustomerBean();
		Assert.assertEquals(2000.00, w.depositDao(2000.00));
		Assert.assertEquals(4000.00, w.depositDao(2000.00));
		
	}
	@SuppressWarnings("deprecation")
	@Test
	public void testWithdrawAmt() throws Exception
	{
		CustomerService w = new CustomerService();
		CustomerBean a = new CustomerBean();
		
		Assert.assertEquals(4000.00, w.depositDao(4000.00));
		Assert.assertEquals(2000.00, w.withdrawDao(2000.00));
		Assert.assertEquals(00.00, w.withdrawDao(2000.00));
		
	}
	
	@Test
	public void testDispBal()
	{
		CustomerService w = new CustomerService();
		CustomerBean a = new CustomerBean();
		Assert.assertEquals(0.00,w.showBalDao());
		
		
	}
	
	@Test
	public void testLogin()
	{
		CustomerDao w = new CustomerDao();
		CustomerBean a = new CustomerBean();
		w.accCreation(a);
		CustomerBean a1 = new CustomerBean();
		w.accCreation(a1);
		CustomerBean a2 = new CustomerBean();
		w.accCreation(a2);
		CustomerBean a3 = new CustomerBean();
		w.accCreation(a3);
		System.out.println(a3.getAccNum());
		Assert.assertEquals(a1, w.loginUser(10104));
	}

}
