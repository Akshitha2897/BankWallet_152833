package com.capgemini.dao;

import java.util.TreeMap;
import  com.capgemini.bean.CustomerBean;


public class CustomerDao implements ICustomerdao {

	TreeMap<Integer, CustomerBean> map = new TreeMap<Integer, CustomerBean>();
	
	
	@Override
	public int accCreation(CustomerBean a) {
		a.setAccNum();
		map.put(a.getAccNum(), a);
		return a.getAccNum();
	}

	@Override
	public CustomerBean loginUser(int accNo) {
		
		return map.get(accNo);		
	}

	@Override
	public void updateDetails(int accNo, CustomerBean a) {
		map.replace(accNo, a);
		
	}

}
