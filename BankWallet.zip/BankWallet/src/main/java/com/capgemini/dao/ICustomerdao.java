package com.capgemini.dao;

import  com.capgemini.bean.CustomerBean;

public interface ICustomerdao {
int accCreation(CustomerBean a);
	
	CustomerBean loginUser(int accNo);
	
	void updateDetails(int accNo, CustomerBean a);
}
