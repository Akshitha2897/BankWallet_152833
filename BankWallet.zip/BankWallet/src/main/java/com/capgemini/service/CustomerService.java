package com.capgemini.service;

import com.capgemini.bean.CustomerBean;
import com.capgemini.dao.CustomerDao;
import com.capgemini.dao.ICustomerdao;



public class CustomerService implements ICustomerService {
	CustomerBean temp = new CustomerBean();
	CustomerDao dao;
	 public CustomerService() {
		 dao = new CustomerDao();
		 
	}
	 
	 static String namePattern = "[A-Z]{1}[a-z]{2,}";
	 static String numberPattern = "(\\d){10}";
	 static String passwordPattern = "[A-Z]{1}[a-z]{2,6}(\\d){1,4}(\\W){1}";
	
	@Override
	public int addAccDao(CustomerBean a) {
		
		return dao.accCreation(a);
	}

	@Override
	public double depositDao(double money) {
		temp.setAmt(temp.getAmt()+money);
		dao.updateDetails(temp.getAccNum(),temp);
		return temp.getAmt();
	}

	@Override
	public double withdrawDao(double money) {
		if(money<temp.getAmt()) {
		temp.setAmt(temp.getAmt()-money);
		dao.updateDetails(temp.getAccNum(),temp);
		}
		else
			System.out.println("Low Balance :( ");
		return temp.getAmt();
	}

	@Override
	public double showBalDao() {
		
		return temp.getAmt();
	}
public  boolean validateCustName(String name)
{	if(name.matches(namePattern))
		return true;
	else
		return false;
	
}
public  boolean validateCustPhoneNumber(String number) {
	if(number.matches(numberPattern))
		return true;
	else
		return false;
}

public boolean validateCustAge(int age) {
	if(age<=110&&age>=1)
		return true;
	else
		return false;
	
}

public  boolean validateCustPwd(String pwd) {
	if(pwd.matches(passwordPattern))
		return true;
	else
		return false;
}

public  boolean validateAmt(double amt) {
if(amt>0.00)
	return true;
else
	return false;
}
@Override
public boolean checkLogin(int accNo) {
	temp =dao.loginUser(accNo);
	if(temp!=null)
	return true;
	else 
		return false;
}
@Override
public boolean checkPassword(String pwd) {
	
	if(temp.getCustPwd().matches(pwd))
		return true;
	else
		return false;

	
}

@Override
public String currentUser() {
	
	return temp.getName();
}

@Override
public boolean transferAmt(int toAccNo, double money) {
	CustomerBean ftTemp =new CustomerBean();
	if(temp.getAmt()>=money) {
	ftTemp = dao.loginUser(toAccNo);
	if(ftTemp!=null)
	{
		ftTemp.setAmt(ftTemp.getAmt()+money);
		temp.setAmt(temp.getAmt()-money);
		dao.updateDetails(temp.getAccNum(), temp);
		dao.updateDetails(ftTemp.getAccNum(), ftTemp);
		return true;
	}
	
	
}
	else if(temp.getAmt()<money)
	{
		System.out.println("Low Balance to transfer");
	}
	
	else
		System.out.println("No such user account");
	return false;
}

}
