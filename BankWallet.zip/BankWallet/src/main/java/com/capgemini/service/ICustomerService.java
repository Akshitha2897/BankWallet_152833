package com.capgemini.service;



import com.capgemini.bean.CustomerBean;

public interface ICustomerService {
	int addAccDao(CustomerBean a);
	double depositDao(double amt);
	double withdrawDao(double amt) ;
	double showBalDao();
	boolean checkLogin(int accNo);
	boolean checkPassword(String pswd);
	String currentUser();
	boolean transferAmt(int tAccNo, double amt);
}
